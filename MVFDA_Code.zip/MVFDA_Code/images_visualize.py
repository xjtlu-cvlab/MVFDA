import os
from PIL import Image, ImageDraw
import tqdm
import cv2
import matplotlib.pyplot as plt
import numpy as np
import torch
import torchvision.transforms as T
import torch.nn.functional as F
from multiview_detector.datasets import frameDataset, Wildtrack, MultiviewX
from multiview_detector.utils.image_utils import img_color_denormalize


def _traget_transform(target, kernel):
    with torch.no_grad():
        target = F.conv2d(target, kernel.float().to(target.device), padding=int((kernel.shape[-1] - 1) / 2))
    return target


def test(dataset_name='multiviewx'):
    if dataset_name == 'multiviewx':
        # result_fpath = 'C:/Users/Jining Zhang/Desktop/SPUMix/Results/SPUMix/MultiviewX/test.txt'
        result_fpath = 'C:/Users/Jining Zhang/Desktop/MVFDA/logs/test_multiviewx_6.txt'
        dataset = frameDataset(MultiviewX(os.path.expanduser('Data/MultiviewX')), False, )
    elif dataset_name == 'wildtrack':
        result_fpath = 'C:/Users/Jining Zhang/Desktop/MVFDA/logs/test_epoch_10.txt'
        dataset = frameDataset(Wildtrack(os.path.expanduser('Data/Wildtrack')), False, )
    else:
        raise Exception('must choose from [wildtrack, multiviewx]')
    grid_size = list(map(lambda x: x * 3, dataset.Rworld_shape))
    bbox_by_pos_cam = dataset.base.read_pom()
    results = np.loadtxt(result_fpath)
    denorm = img_color_denormalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
    reshape_transform = T.Resize(dataset.img_shape)
    for index in tqdm.tqdm(range(len(dataset))):
        map_res = np.zeros(dataset.Rworld_shape)
        imgs, map_gt, imgs_gt, affine_mats, frame = dataset.__getitem__(index)
        imgs = reshape_transform(denorm(imgs))
        res_map_grid = results[results[:, 0] == frame, 1:]
        res_posID = dataset.base.get_pos_from_worldgrid(res_map_grid.transpose())

        # Create a mapping from position ID to color.
        colors = {posID: tuple(map(int, np.random.rand(3) * 255)) for posID in res_posID}

        if dataset_name == 'multiviewx':
            # canvas = cv2.imread('BEV/m.png')
            canvas = cv2.imread('BEV/mvp.png')

            canvas_height, canvas_width = canvas.shape[:2]
            world_height, world_width = dataset.base.worldgrid_shape

            scale_x = canvas_width / world_width
            scale_y = canvas_height / world_height
            for (x, y), posID in zip(res_map_grid, res_posID):
                cv2.circle(canvas, (int(x * scale_x), int(y * scale_y)), 5, colors[posID], -1)
            imgdpath = 'imgs/top view'
            os.makedirs(imgdpath, exist_ok=True)
            cv2.imwrite(os.path.join(imgdpath, f'{frame}.png'), canvas)

        elif dataset_name == 'wildtrack':
            canvas = cv2.imread('BEV/w6.png')
            canvas_height, canvas_width = canvas.shape[:2]

            world_height, world_width = dataset.base.worldgrid_shape

            scale_x = canvas_width / world_width
            scale_y = canvas_height / world_height
            for (x, y), posID in zip(res_map_grid, res_posID):
                cv2.circle(canvas, (int(y * scale_x), int(x * scale_y)), 5, colors[posID], -1)
            imgdpath = 'imgs/top view'
            os.makedirs(imgdpath, exist_ok=True)
            cv2.imwrite(os.path.join(imgdpath, f'{frame}.png'), canvas)

        for cam in range(dataset.num_cam):
            img = (imgs[cam].cpu().numpy().transpose([1, 2, 0]) * 255).astype('uint8')
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

            for i, posID in enumerate(res_posID):
                bbox = bbox_by_pos_cam[posID][cam]
                if bbox is not None:
                    # Use the fixed color assigned to this posID.
                    color = colors[posID]
                    cv2.rectangle(img, tuple(bbox[:2]), tuple(bbox[2:]), color, 3)

            imgppath = f'imgs/cam{cam + 1}'
            os.makedirs(imgppath, exist_ok=True)
            # Use frame number instead of index
            cv2.imwrite(os.path.join(imgppath, f'{frame}.png'), img)


if __name__ == '__main__':
     test('multiviewx')
    # test('wildtrack')