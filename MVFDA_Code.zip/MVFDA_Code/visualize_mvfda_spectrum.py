import argparse
import os
import glob

import cv2
import numpy as np



def compute_lab_descriptor(img: np.ndarray, size: int = 32) -> np.ndarray:
    small = cv2.resize(img, (size, size), interpolation=cv2.INTER_AREA)
    lab = cv2.cvtColor(small, cv2.COLOR_RGB2LAB)
    return lab.astype(np.float32).reshape(-1)


def low_freq_mutate(amp_src: np.ndarray, amp_trg: np.ndarray, beta: float) -> np.ndarray:
    if beta <= 0:
        return amp_src
    h, w = amp_src.shape[:2]
    b = int(np.floor(min(h, w) * beta))
    if b <= 0:
        return amp_src
    c_h, c_w = h // 2, w // 2
    h1, h2 = max(0, c_h - b), min(h, c_h + b)
    w1, w2 = max(0, c_w - b), min(w, c_w + b)
    amp_src_shift = np.fft.fftshift(amp_src, axes=(0, 1))
    amp_trg_shift = np.fft.fftshift(amp_trg, axes=(0, 1))
    amp_src_shift[h1:h2, w1:w2] = amp_trg_shift[h1:h2, w1:w2]
    return np.fft.ifftshift(amp_src_shift, axes=(0, 1))


def mvfda_augment(src_img: np.ndarray, trg_img: np.ndarray, beta: float) -> np.ndarray:
    if beta <= 0:
        return src_img
    src = src_img.astype(np.float32)
    trg = trg_img.astype(np.float32)
    if src.shape[:2] != trg.shape[:2]:
        trg = cv2.resize(trg, (src.shape[1], src.shape[0]))
    fft_src = np.fft.fft2(src, axes=(0, 1))
    fft_trg = np.fft.fft2(trg, axes=(0, 1))
    amp_src, pha_src = np.abs(fft_src), np.angle(fft_src)
    amp_trg = np.abs(fft_trg)
    amp_src = low_freq_mutate(amp_src, amp_trg, beta=beta)
    fft_mut = amp_src * np.exp(1j * pha_src)
    out = np.real(np.fft.ifft2(fft_mut, axes=(0, 1)))
    return np.clip(out, 0, 255).astype(np.uint8)


def load_rgb(path: str) -> np.ndarray:
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Failed to load image: {path}")
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def list_frame_paths(cam_dir: str):
    paths = sorted(
        glob.glob(os.path.join(cam_dir, "*.png"))
        + glob.glob(os.path.join(cam_dir, "*.jpg"))
        + glob.glob(os.path.join(cam_dir, "*.jpeg"))
    )
    if not paths:
        raise FileNotFoundError(f"No images found in {cam_dir}")
    return paths


def resolve_dataset_cam_dir(dataset: str, cam: int) -> str:
    name_map = {
        "mvperception": "MVPerception",
        "multiviewx": "MultiviewXXX",
        "wildtrack": "Wildtrack",
    }
    root = os.path.join("Data", name_map[dataset], "Image_subsets", f"C{cam + 1}")
    if not os.path.isdir(root):
        raise FileNotFoundError(f"Camera folder not found: {root}")
    return root


def fft_amp_phase(img_rgb: np.ndarray):
    """Channel-mean amplitude / phase in FFT-shifted coordinates."""
    x = img_rgb.astype(np.float32)
    fft = np.fft.fft2(x, axes=(0, 1))
    amp = np.abs(fft)
    pha = np.angle(fft)
    amp_shift = np.fft.fftshift(amp, axes=(0, 1)).mean(axis=2)
    pha_shift = np.fft.fftshift(pha, axes=(0, 1)).mean(axis=2)
    return amp_shift, pha_shift


def log_amp_to_uint8(amp: np.ndarray) -> np.ndarray:
    log_amp = np.log1p(amp)
    lo, hi = np.percentile(log_amp, 1), np.percentile(log_amp, 99)
    if hi <= lo:
        hi = lo + 1e-6
    norm = np.clip((log_amp - lo) / (hi - lo), 0, 1)
    return (norm * 255).astype(np.uint8)


def phase_to_uint8(pha: np.ndarray) -> np.ndarray:
    norm = (pha + np.pi) / (2 * np.pi)
    return (np.clip(norm, 0, 1) * 255).astype(np.uint8)


def diff_to_uint8(diff: np.ndarray) -> np.ndarray:
    d = np.abs(diff)
    # emphasize non-zero residual; ignore tiny numerical noise
    thr = np.percentile(d, 99.5)
    if thr <= 0:
        thr = 1.0
    norm = np.clip(d / thr, 0, 1)
    return (norm * 255).astype(np.uint8)


def apply_colormap(gray_u8: np.ndarray) -> np.ndarray:
    bgr = cv2.applyColorMap(gray_u8, cv2.COLORMAP_INFERNO)
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def low_freq_box(h: int, w: int, beta: float):
    b = int(np.floor(min(h, w) * beta))
    c_h, c_w = h // 2, w // 2
    h1, h2 = max(0, c_h - b), min(h, c_h + b)
    w1, w2 = max(0, c_w - b), min(w, c_w + b)
    return h1, h2, w1, w2


def draw_lf_box(rgb: np.ndarray, beta: float, color=(0, 255, 255), thickness=3) -> np.ndarray:
    out = rgb.copy()
    h, w = out.shape[:2]
    h1, h2, w1, w2 = low_freq_box(h, w, beta)
    cv2.rectangle(out, (w1, h1), (w2 - 1, h2 - 1), color, thickness)
    return out


def put_title(rgb: np.ndarray, text: str, bar_h: int = 42) -> np.ndarray:
    h, w = rgb.shape[:2]
    canvas = np.full((h + bar_h, w, 3), 255, dtype=np.uint8)
    canvas[bar_h:] = rgb
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.85
    thickness = 2
    (tw, th), _ = cv2.getTextSize(text, font, scale, thickness)
    x = max(8, (w - tw) // 2)
    y = (bar_h + th) // 2
    cv2.putText(canvas, text, (x, y), font, scale, (20, 20, 20), thickness, cv2.LINE_AA)
    return canvas


def resize_keep(rgb: np.ndarray, out_w: int) -> np.ndarray:
    h, w = rgb.shape[:2]
    out_h = int(round(h * out_w / w))
    return cv2.resize(rgb, (out_w, out_h), interpolation=cv2.INTER_AREA)


def hstack_pad(imgs, gap: int = 12, bg=255):
    heights = [im.shape[0] for im in imgs]
    widths = [im.shape[1] for im in imgs]
    H = max(heights)
    W = sum(widths) + gap * (len(imgs) - 1)
    canvas = np.full((H, W, 3), bg, dtype=np.uint8)
    x = 0
    for im in imgs:
        y = (H - im.shape[0]) // 2
        canvas[y:y + im.shape[0], x:x + im.shape[1]] = im
        x += im.shape[1] + gap
    return canvas


def vstack_pad(imgs, gap: int = 16, bg=255):
    widths = [im.shape[1] for im in imgs]
    heights = [im.shape[0] for im in imgs]
    W = max(widths)
    H = sum(heights) + gap * (len(imgs) - 1)
    canvas = np.full((H, W, 3), bg, dtype=np.uint8)
    y = 0
    for im in imgs:
        x = (W - im.shape[1]) // 2
        canvas[y:y + im.shape[0], x:x + im.shape[1]] = im
        y += im.shape[0] + gap
    return canvas


def dataset_num_frames(dataset: str) -> int:
    return {
        "mvperception": 400,
        "multiviewx": 400,
        "wildtrack": 2000,
    }[dataset]


def frame_id_from_path(path: str) -> int:
    stem = os.path.splitext(os.path.basename(path))[0]
    return int(stem)


def filter_train_paths(paths, num_frame: int, train_ratio: float):
    """Keep only training-split frames, matching frameDataset (range(0, int(N * ratio)))."""
    train_end = int(num_frame * train_ratio)
    train_paths = [p for p in paths if frame_id_from_path(p) < train_end]
    if not train_paths:
        raise RuntimeError(
            f"No training frames found (num_frame={num_frame}, train_ratio={train_ratio}, "
            f"train frame ids are 0..{train_end - 1})."
        )
    return train_paths, train_end


def select_maxdiff_reference(src: np.ndarray, candidate_paths, src_path: str):
    src_desc = compute_lab_descriptor(src)
    best_path, best_diff = None, -1.0
    for path in candidate_paths:
        if os.path.abspath(path) == os.path.abspath(src_path):
            continue
        ref = load_rgb(path)
        if ref.shape[:2] != src.shape[:2]:
            ref = cv2.resize(ref, (src.shape[1], src.shape[0]), interpolation=cv2.INTER_AREA)
        desc = compute_lab_descriptor(ref)
        diff = float(np.linalg.norm(desc - src_desc))
        if diff > best_diff:
            best_diff = diff
            best_path = path
    if best_path is None:
        raise RuntimeError("Failed to select a MaxDiff reference image.")
    return load_rgb(best_path), best_path, best_diff


def zoom_center(rgb: np.ndarray, beta: float, scale: float = 4.0) -> np.ndarray:
    """Crop a slightly larger-than-LF region and magnify for readability."""
    h, w = rgb.shape[:2]
    h1, h2, w1, w2 = low_freq_box(h, w, max(beta * 2.5, beta + 0.02))
    crop = rgb[h1:h2, w1:w2]
    zh = max(1, int(crop.shape[0] * scale))
    zw = max(1, int(crop.shape[1] * scale))
    return cv2.resize(crop, (zw, zh), interpolation=cv2.INTER_NEAREST)


def build_figure(src, ref, aug, beta: float, panel_w: int = 640):
    amp_src, _ = fft_amp_phase(src)
    amp_ref, _ = fft_amp_phase(ref)
    amp_aug, _ = fft_amp_phase(aug)

    # amplitude spectra + LF box
    amp_src_c = draw_lf_box(apply_colormap(log_amp_to_uint8(amp_src)), beta)
    amp_ref_c = draw_lf_box(apply_colormap(log_amp_to_uint8(amp_ref)), beta)
    amp_aug_c = draw_lf_box(apply_colormap(log_amp_to_uint8(amp_aug)), beta)

    amp_src_v = put_title(resize_keep(amp_src_c, panel_w), "(a) Source amplitude")
    amp_ref_v = put_title(resize_keep(amp_ref_c, panel_w), "(b) Reference amplitude")
    amp_aug_v = put_title(resize_keep(amp_aug_c, panel_w), "(c) Augmented amplitude")

    return hstack_pad([amp_src_v, amp_ref_v, amp_aug_v])


def main():
    parser = argparse.ArgumentParser(description="Visualize MVFDA Fourier spectrum before/after swap")
    parser.add_argument("--dataset", type=str, default="mvperception",
                        choices=["mvperception", "multiviewx", "wildtrack"])
    parser.add_argument("--cam", type=int, default=0, help="0-based camera index")
    parser.add_argument("--frame", type=int, default=0, help="source frame index within camera folder")
    parser.add_argument("--ref_frame", type=int, default=-1,
                        help="optional fixed reference frame; -1 = MaxDiff")
    parser.add_argument("--beta", type=float, default=1, help="low-frequency replacement ratio")
    parser.add_argument("--pool_stride", type=int, default=5,
                        help="subsample stride when searching MaxDiff references (speed)")
    parser.add_argument("--train_ratio", type=float, default=0.9,
                        help="same as frameDataset: only use train-split frames as reference pool")
    parser.add_argument("--output_dir", type=str, default="figs/mvfda_spectrum")
    parser.add_argument("--panel_w", type=int, default=640)
    args = parser.parse_args()

    cam_dir = resolve_dataset_cam_dir(args.dataset, args.cam)
    paths = list_frame_paths(cam_dir)
    num_frame = dataset_num_frames(args.dataset)
    train_paths, train_end = filter_train_paths(paths, num_frame, args.train_ratio)

    if args.frame < 0 or args.frame >= len(paths):
        raise ValueError(f"--frame out of range: 0..{len(paths) - 1}")
    src_path = paths[args.frame]
    src_fid = frame_id_from_path(src_path)
    if src_fid >= train_end:
        raise ValueError(
            f"Source frame {src_fid} is in the test split "
            f"(train frames are 0..{train_end - 1}). Pick a training frame."
        )
    src = load_rgb(src_path)

    if args.ref_frame >= 0:
        if args.ref_frame >= len(paths):
            raise ValueError(f"--ref_frame out of range: 0..{len(paths) - 1}")
        ref_path = paths[args.ref_frame]
        ref_fid = frame_id_from_path(ref_path)
        if ref_fid >= train_end:
            raise ValueError(
                f"Reference frame {ref_fid} is in the test split "
                f"(train frames are 0..{train_end - 1})."
            )
        ref = load_rgb(ref_path)
        if ref.shape[:2] != src.shape[:2]:
            ref = cv2.resize(ref, (src.shape[1], src.shape[0]), interpolation=cv2.INTER_AREA)
        ref_diff = float(np.linalg.norm(compute_lab_descriptor(ref) - compute_lab_descriptor(src)))
    else:
        # MaxDiff over train-split same-view pool only (matches training MVFDA)
        candidates = train_paths[:: max(1, args.pool_stride)]
        if src_path not in candidates:
            candidates = [src_path] + candidates
        ref, ref_path, ref_diff = select_maxdiff_reference(src, candidates, src_path)
        if ref.shape[:2] != src.shape[:2]:
            ref = cv2.resize(ref, (src.shape[1], src.shape[0]), interpolation=cv2.INTER_AREA)

    aug = mvfda_augment(src, ref, args.beta)
    figure = build_figure(src, ref, aug, args.beta, panel_w=args.panel_w)

    os.makedirs(args.output_dir, exist_ok=True)
    stem = f"{args.dataset}_C{args.cam + 1}_f{args.frame:04d}_beta{args.beta:.2f}"
    out_png = os.path.join(args.output_dir, f"{stem}.png")
    out_jpg = os.path.join(args.output_dir, f"{stem}.jpg")

    bgr = cv2.cvtColor(figure, cv2.COLOR_RGB2BGR)
    cv2.imwrite(out_png, bgr)
    cv2.imwrite(out_jpg, bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 95])

    # also dump individual panels for flexible LaTeX layout
    panel_dir = os.path.join(args.output_dir, stem + "_panels")
    os.makedirs(panel_dir, exist_ok=True)
    amp_src, _ = fft_amp_phase(src)
    amp_ref, _ = fft_amp_phase(ref)
    amp_aug, _ = fft_amp_phase(aug)
    amp_src_c = draw_lf_box(apply_colormap(log_amp_to_uint8(amp_src)), args.beta)
    amp_ref_c = draw_lf_box(apply_colormap(log_amp_to_uint8(amp_ref)), args.beta)
    amp_aug_c = draw_lf_box(apply_colormap(log_amp_to_uint8(amp_aug)), args.beta)
    panels = {
        "01_amp_source.png": amp_src_c,
        "02_amp_reference.png": amp_ref_c,
        "03_amp_augmented.png": amp_aug_c,
    }
    for name, arr in panels.items():
        cv2.imwrite(os.path.join(panel_dir, name), cv2.cvtColor(arr, cv2.COLOR_RGB2BGR))

    # paper-facing copy next to the .tex manuscript
    paper_fig = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Figure spectrum.png")
    cv2.imwrite(paper_fig, bgr)

    print(f"Saved figure: {out_png}")
    print(f"Saved figure: {out_jpg}")
    print(f"Saved paper figure: {paper_fig}")
    print(f"Saved panels: {panel_dir}")
    print(f"Source: {src_path} (frame {src_fid})")
    print(f"Reference: {ref_path} (frame {frame_id_from_path(ref_path)})")
    print(f"Train split: frames 0..{train_end - 1} (train_ratio={args.train_ratio})")
    print(f"MaxDiff L2 (Lab desc): {ref_diff:.2f}")
    print(f"beta={args.beta}")


if __name__ == "__main__":
    main()
