import os
import random
import numpy as np
import cv2
from PIL import Image
from typing import Dict, List, Tuple, Optional, Union


class MVFDAModule:
    """
    MVFDA: Frequency Domain Augmentation for Multi-View Pedestrian Detection
    
    Args:
        num_cameras: Number of camera views. 
                     Automatically determined from dataset:
                     - MVPerception: 6 cameras
                     - MultiviewX: 6 cameras
                     - Wildtrack: 7 cameras
        mvfda_beta: Replacement ratio (0-1).
        mvfda_prob: Probability of applying MVFDA in each camera view (0-1).
        ref_mode: reference selection strategy.
                  - 'random':       randomly pick a reference image.
                  - 'maxdiff':      MaxDiff using CIELab Euclidean distance.
                  - 'maxdiff_ssim': MaxDiff using structural dissimilarity (1 - SSIM).
        descriptor_size: Size for appearance descriptor computation (default: 32)
    
    """
    
    def __init__(
        self,
        num_cameras: int,
        mvfda_beta: float = 0.1,
        mvfda_prob: float = 0.75,
        ref_mode: str = 'maxdiff',
        descriptor_size: int = 32
    ):
        self.num_cameras = num_cameras
        self.mvfda_beta = mvfda_beta
        self.mvfda_prob = mvfda_prob
        self.ref_mode = ref_mode
        self.descriptor_size = descriptor_size
        
        self.use_mvfda = mvfda_beta > 0 and mvfda_prob > 0
        self.use_ssim = ref_mode == 'maxdiff_ssim'
        self.need_descriptor = ref_mode in ('maxdiff', 'maxdiff_ssim')
        
        # Reference pools for each camera
        self.reference_pools: List[Dict] = [None] * num_cameras
        
    def build_reference_pool(
        self,
        img_fpaths: Dict[int, Dict[int, str]],
        frame_range: range
    ) -> None:
        if not self.use_mvfda:
            return
            
        self.reference_pools = []
        
        for cam in range(self.num_cameras):
            paths, frames, descriptors = [], [], []
            
            for frame in frame_range:
                if frame in img_fpaths.get(cam, {}):
                    path = img_fpaths[cam][frame]
                    paths.append(path)
                    frames.append(frame)
                    
                    if self.need_descriptor:
                        try:
                            with Image.open(path) as im:
                                img = np.array(im.convert('RGB'))
                            desc = self._compute_descriptor(img)
                            descriptors.append(desc)
                        except Exception as e:
                            print(f"Warning: Failed to load {path}: {e}")
                            descriptors.append(None)
            
            if self.need_descriptor and descriptors:
                valid_indices = [i for i, d in enumerate(descriptors) if d is not None]
                paths = [paths[i] for i in valid_indices]
                frames = [frames[i] for i in valid_indices]
                descriptors = [descriptors[i] for i in valid_indices]
                
                if descriptors:
                    descriptors = np.stack(descriptors).astype(np.float32)
                else:
                    descriptors = None
            else:
                descriptors = None
            
            pool = {
                'paths': paths,
                'frames': np.array(frames) if frames else np.array([], dtype=int),
                'descriptors': descriptors
            }
            self.reference_pools.append(pool)
    
    def apply(
        self,
        img: np.ndarray,
        cam: int,
        frame: Optional[int] = None
    ) -> np.ndarray:

        if not self.use_mvfda:
            return img
            
        if np.random.rand() >= self.mvfda_prob:
            return img
            
        if cam >= len(self.reference_pools) or self.reference_pools[cam] is None:
            return img
            
        pool = self.reference_pools[cam]
        if not pool['paths']:
            return img
        
        ref_img = self._select_reference(img, cam, frame, pool)
        if ref_img is None:
            return img
        
        augmented_img = self._mvfda_augment(img, ref_img, self.mvfda_beta)
        
        return augmented_img
    
    def _select_reference(
        self,
        src_img: np.ndarray,
        cam: int,
        frame: Optional[int],
        pool: Dict
    ) -> Optional[np.ndarray]:

        if self.need_descriptor and pool['descriptors'] is not None:
            # MaxDiff strategy: select image with largest appearance difference
            src_desc = self._compute_descriptor(src_img)

            if self.use_ssim:
                # Structural dissimilarity (1 - SSIM); larger means more dissimilar.
                diffs = np.array(
                    [1.0 - self._ssim(src_desc, ref) for ref in pool['descriptors']],
                    dtype=np.float32
                )
            else:
                # CIELab Euclidean distance in a flattened descriptor space.
                diffs = np.linalg.norm(
                    pool['descriptors'] - src_desc[None, :],
                    axis=1
                )
            
            if frame is not None:
                same_frame_mask = pool['frames'] == frame
                diffs[same_frame_mask] = -1
            
            best_idx = np.argmax(diffs)
            
            if diffs[best_idx] <= 0:
                target_path = random.choice(pool['paths'])
            else:
                target_path = pool['paths'][best_idx]
        else:
            target_path = random.choice(pool['paths'])
        
        try:
            with Image.open(target_path) as im:
                return np.array(im.convert('RGB'))
        except Exception as e:
            print(f"Warning: Failed to load reference {target_path}: {e}")
            return None
    
    def _compute_descriptor(self, img: np.ndarray) -> np.ndarray:
        """
        Compute an appearance descriptor for measuring appearance difference.

        - 'maxdiff'      -> flattened CIELab descriptor (for Euclidean distance).
        - 'maxdiff_ssim' -> 2D grayscale patch (for structural similarity, SSIM).
        """
        small = cv2.resize(
            img,
            (self.descriptor_size, self.descriptor_size),
            interpolation=cv2.INTER_AREA
        )

        if self.use_ssim:
            gray = cv2.cvtColor(small, cv2.COLOR_RGB2GRAY)
            return gray.astype(np.float32)

        lab = cv2.cvtColor(small, cv2.COLOR_RGB2LAB)

        return lab.astype(np.float32).reshape(-1)

    @staticmethod
    def _ssim(img1: np.ndarray, img2: np.ndarray) -> float:
        """
        Compute the (global) structural similarity index (SSIM) between two
        single-channel images, following Wang et al. (2004). Both inputs are
        expected to be float grayscale patches with values in [0, 255].
        """
        C1 = (0.01 * 255) ** 2
        C2 = (0.03 * 255) ** 2

        ksize, sigma = (11, 11), 1.5
        mu1 = cv2.GaussianBlur(img1, ksize, sigma)
        mu2 = cv2.GaussianBlur(img2, ksize, sigma)

        mu1_sq, mu2_sq, mu1_mu2 = mu1 * mu1, mu2 * mu2, mu1 * mu2
        sigma1_sq = cv2.GaussianBlur(img1 * img1, ksize, sigma) - mu1_sq
        sigma2_sq = cv2.GaussianBlur(img2 * img2, ksize, sigma) - mu2_sq
        sigma12 = cv2.GaussianBlur(img1 * img2, ksize, sigma) - mu1_mu2

        ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / \
                   ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

        return float(ssim_map.mean())
    
    @staticmethod
    def _low_freq_mutate(
        amp_src: np.ndarray,
        amp_trg: np.ndarray,
        beta: float
    ) -> np.ndarray:

        if beta <= 0:
            return amp_src
            
        h, w = amp_src.shape[:2]
        b = int(np.floor(min(h, w) * beta))
        
        if b <= 0:
            return amp_src
            
        c_h, c_w = h // 2, w // 2
        h1, h2 = c_h - b, c_h + b
        w1, w2 = c_w - b, c_w + b
        

        h1 = max(0, h1)
        h2 = min(h, h2)
        w1 = max(0, w1)
        w2 = min(w, w2)
        
        amp_src_shift = np.fft.fftshift(amp_src, axes=(0, 1))
        amp_trg_shift = np.fft.fftshift(amp_trg, axes=(0, 1))
        amp_src_shift[h1:h2, w1:w2] = amp_trg_shift[h1:h2, w1:w2]
        
        return np.fft.ifftshift(amp_src_shift, axes=(0, 1))
    
    @staticmethod
    def _mvfda_augment(
        src_img: np.ndarray,
        trg_img: np.ndarray,
        beta: float
    ) -> np.ndarray:

        if beta <= 0:
            return src_img
        
        src = src_img.astype(np.float32)
        trg = trg_img.astype(np.float32)
        
        if src.shape[:2] != trg.shape[:2]:
            trg = cv2.resize(trg, (src.shape[1], src.shape[0]))
        
        fft_src = np.fft.fft2(src, axes=(0, 1))
        fft_trg = np.fft.fft2(trg, axes=(0, 1))
        
        amp_src, pha_src = np.abs(fft_src), np.angle(fft_src)
        amp_trg = np.abs(fft_trg)
        
        amp_src = MVFDAModule._low_freq_mutate(amp_src, amp_trg, beta=beta)
        
        fft_src_mutated = amp_src * np.exp(1j * pha_src)
        img_src_in_trg = np.fft.ifft2(fft_src_mutated, axes=(0, 1))
        img_src_in_trg = np.real(img_src_in_trg)
        
        img_src_in_trg = np.clip(img_src_in_trg, 0, 255).astype(np.uint8)
        
        return img_src_in_trg
    
    def reset(self) -> None:
        self.reference_pools = [None] * self.num_cameras
    
    def get_config(self) -> Dict:
        """Get current configuration."""
        return {
            'num_cameras': self.num_cameras,
            'mvfda_beta': self.mvfda_beta,
            'mvfda_prob': self.mvfda_prob,
            'ref_mode': self.ref_mode,
            'descriptor_size': self.descriptor_size,
            'use_mvfda': self.use_mvfda
        }



def mvfda_augment(src_img: np.ndarray, trg_img: np.ndarray, beta: float = 0.01) -> np.ndarray:
    return MVFDAModule._mvfda_augment(src_img, trg_img, beta)

