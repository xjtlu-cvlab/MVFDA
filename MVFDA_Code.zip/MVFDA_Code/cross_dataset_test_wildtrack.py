import os
os.environ['OMP_NUM_THREADS'] = '1'
import argparse
import sys
import datetime
import torch
from torch.utils.data import DataLoader
from multiview_detector.datasets import Wildtrack
from multiview_detector.datasets.frameDataset import frameDataset
from multiview_detector.models.mvdetr import MVDeTr
from multiview_detector.trainer import PerspectiveTrainer
from multiview_detector.utils.logger import Logger


def main(args):
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    
    # Create output directory
    date_time_now = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    output_dir = f'test_results/multiviewx_on_wildtrack-{date_time_now}'
    os.makedirs(output_dir, exist_ok=True)
    
    # Create log file
    log_file = os.path.join(output_dir, 'output.log')
    sys.stdout = Logger(log_file)
    print(f'Output directory: {output_dir}')
    print('Test settings:')
    print(vars(args))
    
    # Load Wildtrack dataset (test split: last 10% of frames)
    print('\nLoading Wildtrack dataset...')
    base = Wildtrack(os.path.expanduser('Data/Wildtrack'))
    test_set = frameDataset(
        base, 
        train=False,  # train=False uses the last 10% of frames (default train_ratio=0.9)
        world_reduce=args.world_reduce,
        img_reduce=args.img_reduce, 
        world_kernel_size=args.world_kernel_size,
        img_kernel_size=args.img_kernel_size
    )
    
    print(f'Test frames: {len(test_set)}')
    print(f'Total frames: {base.num_frame}')
    print(f'Test frame range: {int(base.num_frame * 0.9)} - {base.num_frame - 1}')
    
    # Create data loader
    test_loader = DataLoader(
        test_set, 
        batch_size=args.batch_size, 
        shuffle=False, 
        num_workers=args.num_workers,
        pin_memory=True
    )
    
    # Create model
    print('\nCreating model...')
    model = MVDeTr(
        test_set, 
        arch=args.arch, 
        world_feat_arch=args.world_feat,
        bottleneck_dim=args.bottleneck_dim, 
        outfeat_dim=args.outfeat_dim, 
        droupout=args.dropout
    ).to(device)
    
    # Create trainer
    trainer = PerspectiveTrainer(
        model, 
        output_dir, 
        cls_thres=args.cls_thres, 
        alpha=args.alpha, 
        use_mse=args.use_mse, 
        id_ratio=args.id_ratio
    )
    
    # Determine which model checkpoints to evaluate
    model_dir = 'multiviewx_epoch'
    if args.epoch is not None:
        # Evaluate a specific epoch
        model_files = [f'MultiviewDetector_epoch_{args.epoch}.pth']
    else:
        # Evaluate all epochs
        model_files = sorted([f for f in os.listdir(model_dir) if f.endswith('.pth')])
    
    print(f'\nFound {len(model_files)} model file(s)')
    
    # Collect test results
    results_summary = []
    
    # Evaluate each model
    for model_file in model_files:
        model_path = os.path.join(model_dir, model_file)
        if not os.path.exists(model_path):
            print(f'Warning: model file not found: {model_path}')
            continue
        
        epoch_num = model_file.replace('MultiviewDetector_epoch_', '').replace('.pth', '')
        print(f'\n{"="*60}')
        print(f'Testing model: {model_file} (Epoch {epoch_num})')
        print(f'{"="*60}')
        
        # Load model weights
        try:
            model.load_state_dict(torch.load(model_path, map_location=device))
            model.eval()
            print(f'Successfully loaded model: {model_path}')
        except Exception as e:
            print(f'Failed to load model: {e}')
            continue
        
        # Run evaluation
        result_fpath = os.path.join(output_dir, f'wildtrack_test_epoch_{epoch_num}.txt')
        test_loss, moda = trainer.test(None, test_loader, result_fpath, visualize=False)
        
        # Record results
        results_summary.append({
            'epoch': epoch_num,
            'model_file': model_file,
            'test_loss': test_loss,
            'moda': moda
        })
        
        print(f'Epoch {epoch_num} - Loss: {test_loss:.6f}, MODA: {moda:.1f}%')
    
    # Save results summary
    summary_fpath = os.path.join(output_dir, 'test_summary.txt')
    with open(summary_fpath, 'w', encoding='utf-8') as f:
        f.write('Test Results Summary\n')
        f.write('='*60 + '\n')
        f.write(f'Dataset: Wildtrack (last 10% frames)\n')
        f.write(f'Test time: {date_time_now}\n')
        f.write(f'Model source: {model_dir}\n')
        f.write('='*60 + '\n\n')
        
        # Sort by MODA
        results_summary_sorted = sorted(results_summary, key=lambda x: x['moda'], reverse=True)
        
        f.write(f'{"Epoch":<10} {"Loss":<15} {"MODA (%)":<15} {"Model file":<30}\n')
        f.write('-'*60 + '\n')
        for result in results_summary_sorted:
            f.write(f"{result['epoch']:<10} {result['test_loss']:<15.6f} {result['moda']:<15.1f} {result['model_file']:<30}\n")
        
        f.write('\n' + '='*60 + '\n')
        if results_summary_sorted:
            best = results_summary_sorted[0]
            f.write(f'Best model: Epoch {best["epoch"]} (MODA: {best["moda"]:.1f}%)\n')
    
    print(f'\n{"="*60}')
    print('Testing finished!')
    print(f'Results saved to: {output_dir}')
    print(f'Summary file: {summary_fpath}')
    if results_summary:
        best = sorted(results_summary, key=lambda x: x['moda'], reverse=True)[0]
        print(f'Best model: Epoch {best["epoch"]} (MODA: {best["moda"]:.1f}%)')
    print(f'{"="*60}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Evaluate MultiviewX-trained models on the Wildtrack dataset')
    
    # Model arguments
    parser.add_argument('--epoch', type=int, default=None, 
                        help='epoch to evaluate; if omitted, evaluate all epochs')
    parser.add_argument('--arch', type=str, default='resnet18', 
                        choices=['vgg11', 'resnet18'], 
                        help='backbone architecture')
    parser.add_argument('--world_feat', type=str, default='deform_trans',
                        choices=['conv', 'trans', 'deform_conv', 'deform_trans', 'aio'],
                        help='world-feature extraction architecture')
    parser.add_argument('--bottleneck_dim', type=int, default=128,
                        help='bottleneck dimension')
    parser.add_argument('--outfeat_dim', type=int, default=0,
                        help='output feature dimension')
    parser.add_argument('--dropout', type=float, default=0.0,
                        help='dropout rate')
    
    # Dataset arguments
    parser.add_argument('--world_reduce', type=int, default=4,
                        help='world-coordinate downsample factor')
    parser.add_argument('--img_reduce', type=int, default=12,
                        help='image downsample factor')
    parser.add_argument('--world_kernel_size', type=int, default=10,
                        help='Gaussian kernel size for world coordinates')
    parser.add_argument('--img_kernel_size', type=int, default=10,
                        help='Gaussian kernel size for images')
    
    # Evaluation arguments
    parser.add_argument('--cls_thres', type=float, default=0.6,
                        help='classification threshold')
    parser.add_argument('--alpha', type=float, default=1.0,
                        help='weight for per-view loss')
    parser.add_argument('--use_mse', action='store_true',
                        help='use MSE loss')
    parser.add_argument('--id_ratio', type=float, default=0,
                        help='ID loss weight')
    parser.add_argument('-b', '--batch_size', type=int, default=1,
                        help='batch size')
    parser.add_argument('-j', '--num_workers', type=int, default=4,
                        help='number of data-loader workers')
    
    args = parser.parse_args()
    
    main(args)
